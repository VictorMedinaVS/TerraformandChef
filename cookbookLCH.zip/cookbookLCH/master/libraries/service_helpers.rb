

module TomcatCookbook
  module ServiceHelpers

    def derived_install_path
      new_resource.install_path ? new_resource.install_path.chomp('/') : "/opt/tomcat_#{new_resource.instance_name}"
    end

    def envs_with_catalina_base
      return new_resource.env_vars if new_resource.env_vars.any? { |env_hash| env_hash.key?('CATALINA_BASE') }

      env_vars = new_resource.env_vars.dup
      env_vars.unshift('CATALINA_BASE' => derived_install_path)
      env_vars
    end

    def platform_sysv_init_class
      value_for_platform_family(
        'debian' => Chef::Provider::Service::Init::Debian,
        'default' => Chef::Provider::Service::Init::Redhat
      )
    end
  end
end
